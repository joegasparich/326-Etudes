/**
 * William Sanson 4213239
 * Ryan Swanepoel 6535816
 * Will Shaw      8291780
 * Daniel Thomson 5040702
 * Using C++11 
 */

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <cstdlib>
#include <algorithm>

using namespace std;

bool notComment(string str){
    if(str.at(0) == '#') return false;
    return true;
}

bool charCheck(string str){
    if(str.length() == 0) return true;
    return false;
}

bool isSilentEnd(string word,int numVowels){
    char vowels[] = { 'a', 'e', 'i', 'o', 'u', 'y' };
    string silents[] = {"Reserve", "Preserve", "Curve", "Expense",
        "Clothe", "Handle", "Hence", "Bible"};
    if (word == "able") return false;
    if (word.at(word.length() -1) == 'e' && numVowels > 1){
        if (word.length() <=4)return true;

        for (int i = 0; i<8;i++){
            if (word == silents[i])return true;
        }

        for(int i = 0; i<6;i++){
            if (word.at(word.length() -3) == vowels[i])return true;
        }
    }
    return false;
}

int CountSyllables(string word) {
    char vowels[] = { 'a', 'e', 'i', 'o', 'u', 'y' };
    string currentWord = word;
    int numVowels = 0;
    int count = 0;
    bool lastWasVowel = false;
    for(int j = 0; j<currentWord.size();j++) {
        bool foundVowel = false;
        for(int i = 0; i<6;i++) {
            //don't count diphthongs
            if (vowels[i] == currentWord[j] && lastWasVowel) {
                count++;
                if(count>2) {
                    numVowels++;
                    count=0;
                }
                foundVowel = true;
                lastWasVowel = true;
                break;
            } else if (vowels[i] == currentWord[j] && !lastWasVowel) {
                numVowels++;
                count = 0;
                foundVowel = true;
                lastWasVowel = true;
                break;
            }
        }

        if (!foundVowel)
            lastWasVowel = false;
    }
    //remove es, it's _usually? silent
    if (currentWord.length() > 2 && 
        currentWord.substr(currentWord.length() - 2) == "es") {
            if (currentWord.at(currentWord.length() - 3) != 's'|| 
                currentWord.at(currentWord.length() - 3) != 'z'|| 
                currentWord.at(currentWord.length() - 3) != 'g') {
                numVowels--;
            }
        }
        if (currentWord.length() > 4) {
        if(currentWord.substr(currentWord.length() - 4) == "shes" ||
            currentWord.substr(currentWord.length() - 5) == "ables") {
            numVowels++;
        }
    } else if (isSilentEnd(currentWord, numVowels)) {
        // remove silent e.
        numVowels--;
    }
    
    if(numVowels <1) { 
        numVowels = 1;
    }
    return numVowels;
}

int main () {
    bool inputBlank = false;
    while (!inputBlank) {
        string mystr;
        vector<string> storage;
        int i;
        bool inputNotNum = true;

        getline (cin,mystr);
        inputBlank = charCheck(mystr);

        while (!inputBlank) {
            if(notComment(mystr)) { 
                storage.push_back(mystr);
            }
            getline (cin,mystr);
            inputBlank = charCheck(mystr);  
        }

        for(int i= 0; i<storage.size();i++) {
            cout << CountSyllables(storage.at(i)) << endl;
        }
        storage.clear();
    }
}
