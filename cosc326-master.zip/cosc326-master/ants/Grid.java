/**
 * Grid class for saving the state of a known grid.
 * @author Daniel Thomson & Will Shaw
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */
public class Grid {

    // The x coordinate of the grid.
    private final int x;
    // The y coordinate of the grid.
    private final int y;
    // The marker (state) of the grid.
    private char marker;

    /**
     * Constructor for creating a grid section.
     */
    public Grid(int x, int y, char marker) {
        this.x = x;
        this.y = y;
        this.marker = marker;
    }

    /**
     * Updates the marker on this grid.
     */
    public void updateMarker(char marker) {
        this.marker = marker;
    }

    /**
     * Retrieves the marker on this grid.
     */
    public char getMarker() {
        return this.marker;
    }

    /**
     * Used to determine if a grid is known.
     */
    @Override
    public boolean equals(Object object) {
        if (object instanceof Grid && 
            (((Grid) object).x == this.x && ((Grid) object).y == this.y)) {
            return true;
        }
        return false;
    }

    /**
     * Used to generate a key for this grid.
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + this.x;
        hash = 89 * hash + this.y;
        return hash;
    }

    /**
     * String representation of the grid section.
     */
    @Override
    public String toString() { 
        return "[" + this.x + "," + this.y + ",[" + this.marker + "]]";
    }

}