/** Main
 * @author Daniel Thomson & Will Shaw
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */

import java.util.Scanner;
import java.util.ArrayList;

/** 
 * Ants main class.
 */
public class AntsMain {
    //List contain Ant objects for each input scenario.
    private static ArrayList<Ant> ants = new ArrayList<>();

    /**
     * Reads in input and put it in to Ant objects for each inputted
     * scenario.
     * @param args command line arguments.
     */
    public static void main(String args[]) {

        Scanner sc = new Scanner(System.in);

        String digit = "^\\d+";
        String comment = "^#.*";

        String line;

        Ant ant = new Ant();

        while (sc.hasNextLine()) {
            line = sc.nextLine();

            // Ignore empty lines and comment lines.
            if (!line.isEmpty() && !line.matches(comment)) {

                if (line.matches(digit)) {
                    ant.setSteps(Integer.parseInt(line));
                    ants.add(ant);
                    ant = new Ant();
                } else {
                    ant.addDna(line);
                }
            }
        }

        sc.close(); // Finished receiving input, close scanner.

        for (int i = 0; i < ants.size(); i++) {
            
            ants.get(i).walk();        
            System.out.println(ants.get(i).printScenario());
            System.out.println(ants.get(i).printCoordinates());           
        }

    }

}

