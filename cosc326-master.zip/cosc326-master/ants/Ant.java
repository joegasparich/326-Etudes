/** Ant
 * @author Daniel Thomson & Will Shaw
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class for storing scenario info, including DNA,
 *  number of required steps, the plane and its state.
 */
public class Ant {

    /**
     * Enum class for representing the current direction 
     * of the ant
     */
    public enum Direction {

        N(2), E(3), S(4), W(5);

        //value of direction
        private final int value;

        /**
         * Constructor that set direction with given value.
         * 
         * @param value initial direction of the ant.
         */
        private Direction(int value) {
            this.value = value;
        }

        /**
         * Retrieves the value of the direction
         * 
         * @return value of direction.
         */
        public int getValue() {
            return this.value;
        }
    }

    // The number of steps the ant must take.
    private int steps;
    // List containing String for the DNA of the ant
    private List<String> scenario;

    // Posistion of the ant on the plane.
    private int posX = 0;
    private int posY = 0;

    // State of cell ant is currently in.
    private char state;
    // Default state of any non-touched grid section.
    private char initialState;
    // Index for keep trak of DNA line being used to move ant.
    private int dnaIndex = 0;

    /** Stores the known grid elements. Reduces space complexity.
    * Keys are generated from the object itself, meaning when we
    * land on a square we can quickly determine it's location 
    * (if at all) in the map. 
    */
    private HashMap<Integer, Grid> knownGrids = new HashMap<>();

    // Current direction ant is facing.
    private Direction facing = Direction.N;

    /**
     * Construtor that initialise the list of DNA.
     */
    public Ant() {
        this.scenario = new ArrayList<String>();
    }

    /**
     * Sets the number of steps ant will take and uses value
     * to set size of plane array.
     * 
     * @param steps number of steps
     */
    public void setSteps(int steps) {
        this.steps = steps;
        initialState = scenario.get(0).charAt(0);
        state = scenario.get(0).charAt(0);
    }

    /**
     * Adds given DNA string to the lsit of DNA.
     * 
     * @param dna DNA String being added
     */
    public void addDna(String dna) {
        this.scenario.add(dna);
    }

    /**
     * Moves the ant the set number steps through the plane.
     * Uses the set of DNA to determin each move and updates the
     * state of the plane as it moves.
     */
    public void walk() {

        // Move to next location; in a direction. (updates position).
        // Drop mark in old location.
        // Read new location mark.
        // Find matching state encoding.
        // Get next direction based on current facing direction.

        int stepCount = 0;
        while (stepCount < steps) {
            drop(scenario.get(dnaIndex).charAt(facing.getValue() + 5));
            move(String.valueOf(
                scenario.get(dnaIndex).charAt(facing.getValue())));
            this.state = read();            
            this.dnaIndex = find();
            stepCount ++;
        }

    }

    /** 
     * Uses an objects hashCode as a key to quickly
     * find that object in the hashmap.
     * 
     * @param marker new state of the cell
     */
    private void drop(char marker) {
        Grid grid = new Grid(posX, posY, marker);
        knownGrids.put(grid.hashCode(), grid);
    }

    /**
     * Retrieves the index of the DNA related to the current
     * state the ant is on.
     * 
     * @return index of DNA.
     */
    public int find() {
        for (int i = 0; i < scenario.size(); i++) {
            if (scenario.get(i).charAt(0) == state) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Retrieves the state of the current cell the
     * ant is on. The objects key is the hashCode of that 
     * object, increases time efficiency.
     * 
     * @return State of current cell
     */
    private char read() {
        Grid grid = new Grid(posX, posY, initialState);
        int hash = grid.hashCode();
        if (knownGrids.containsKey(hash)) {
            return knownGrids.get(hash).getMarker();
        }
        return initialState;
    }

    /**
     * Moves the ant one move, updating direction ant is facing
     * and its posistion.
     */
    private void move(String dir) {
        int x = 0, y = 0;

        facing = Direction.valueOf(dir);
        switch (dir) {
        case "N":
            y = 1;
            break;
        case "E":
            x = 1;
            break;
        case "S":
            y = -1;
            break;
        case "W":
            x = -1;
            break;
        }

        this.posX += x;
        this.posY += y;
    }

    /**
     * To String method for ant. Prints DNA list and number of steps.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\tDna:\t{ ");
        for (String dna : scenario) {
            sb.append(dna).append(", ");
        }
        sb.append("\b\b }\n\tSteps:\t").append(steps).append("\n ");
        return sb.toString();
    }

    public String printScenario() {
        StringBuilder sb = new StringBuilder();
        for(String dna : scenario) {
            sb.append(dna).append('\n');
        } 
        sb.append(steps);
        return sb.toString();
    }

    /**
     * Prints coordinates of current posistion of ant
     */
    public String printCoordinates() {
        return "# " + (this.posX) + " " + (this.posY) + "\n";
    }

}

