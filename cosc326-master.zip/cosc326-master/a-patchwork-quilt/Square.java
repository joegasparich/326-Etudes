
/** Will Shaw - Square Class
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;

/** A tidy way to easliy access the information required. */
public class Square {

    /* The square's colour. */
    private Color color;
    /* The scale of the square, relative to Quilt.DEFFAULT_WIDTH. */
    private double scale;
    /** Top left point of this square. */
    private Point drawPoint;

    /** Creates a new Square with appropriate color and scale. */
    public Square(String[] config) {
        this.scale = Double.valueOf(config[0]);
        this.color = new Color(Integer.parseInt(config[1]), 
            Integer.parseInt(config[2]), Integer.parseInt(config[3]));
    }

    public Square(Square sq, Point point) {
        this.color = sq.color;
        this.scale = sq.scale;
        this.drawPoint = point;
    }

    /** Returns the scale of this square. */
    public double getScale() {
        return scale;
    }

    public void setScale(double scale) {
        this.scale = scale;
    }

    /** Draws this square on the given Graphics object. */
    public void draw(Graphics2D g2d) {
        g2d.setColor(color);
        g2d.fillRect(drawPoint.x, drawPoint.y, 
            (int) (scale * QuiltPanel.multiplier), 
            (int) (scale * QuiltPanel.multiplier));
    }

}
