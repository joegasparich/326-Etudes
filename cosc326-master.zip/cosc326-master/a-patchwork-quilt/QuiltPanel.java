
/** Will Shaw - QuiltPanel Class
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.List;
import java.util.ArrayList;

import javax.swing.JPanel;

public class QuiltPanel extends JPanel {

    public static double multiplier;

    private List<ArrayList<Square>> paintLayers = new ArrayList<>();

    /** Constructs a panel with dimensions set by the first square's scale. */
    public QuiltPanel(double sizeMultiplier) {
        multiplier = sizeMultiplier;
        build((int) 400, 400, (int) (Quilt.list.get(0).getScale() * multiplier), 0);
    }

    /** Paint method. Draws Squares from the lists. */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        g2d.setPaintMode();

        for (int i = 0; i < paintLayers.size(); i++) {
            for (int c = 0; c < paintLayers.get(i).size(); c++) {
                paintLayers.get(i).get(c).draw(g2d);
            }
        }
    }

    /** Recursive function to build the pattern.
     * Due to the nature of recursion, I have to build a list of lists
     * so that the 'layers' are drawn in the correct order from that list.
     */
    public void build(int topLeftX, int topLeftY, int prevWidth, int depth) {
        if (depth >= Quilt.list.size()) {
            return;
        }

        int currWidth = (int) (Quilt.list.get(depth).getScale() * multiplier);

        if (paintLayers.size() - 1 < depth) {
            paintLayers.add(new ArrayList<Square>());
        }

        Square sq = new Square(Quilt.list.get(depth), 
            new Point((int)topLeftX - (currWidth / 2), 
                (int)topLeftY - (currWidth / 2)));

        paintLayers.get(depth).add(sq);

        // Top left corner.
        build(topLeftX - (currWidth / 2), topLeftY - (currWidth / 2), 
            currWidth, depth + 1);

        // Top right corner.
        build(topLeftX - (currWidth / 2) + currWidth, topLeftY - 
            (currWidth / 2), currWidth, depth + 1);

        // Bottom left corner.
        build(topLeftX - (currWidth / 2), topLeftY - (currWidth / 2) + 
            currWidth, currWidth, depth + 1);

        // Bottom right corner.
        build(topLeftX - (currWidth / 2) + currWidth, topLeftY - 
            (currWidth / 2) + currWidth, currWidth, depth + 1);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(800, 800);
    }

}
