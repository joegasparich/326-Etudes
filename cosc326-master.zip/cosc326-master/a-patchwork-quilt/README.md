# Will Shaw - COSC326 - Quilt
# Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
  
## Build: 
`javac *.java`

## Run: 
`java Quilt < input`
