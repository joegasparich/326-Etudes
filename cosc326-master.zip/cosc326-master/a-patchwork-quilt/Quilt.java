/** Will Shaw - Quilt Class
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */
import java.awt.Color;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFrame;

public class Quilt {

    /* Contains a list of Squares. */
    public static ArrayList<Square> list = new ArrayList<>();

    public static void main(String[] args) {
        new Quilt();
    }

    /** Reads in the input file from System.in and
     *  adds it to a list of Squares.
     */
    public Quilt() {

        Scanner sc = new Scanner(System.in);
        String line;
        String comment = "^#.*";

        Boolean firstLine = true;
        double totalSize = 0.0;

        while (sc.hasNextLine()) {
            line = sc.nextLine();

            if (!line.isEmpty() && !line.matches(comment)) {
                if (firstLine) {
                    list.add(new Square(line.split("\\s")));
                    totalSize += (Double.parseDouble(line.split("\\s")[0]));            
                    firstLine = false;
                } else {
                    Square sq = new Square(line.split("\\s"));
                    double scale = list.get(0).getScale() * Double.parseDouble(line.split("\\s")[0]);
                    sq.setScale(scale);
                    list.add(sq);
                    totalSize += scale;
                }
            }
        }
        double sizeMultiplier = (700 / totalSize);

        sc.close();
        createWindow(sizeMultiplier);
    }

    /** Creates the GUI window to display the graphic. */
    public void createWindow(double sizeMultiplier) {
        JFrame frame = new JFrame();
        frame.setBackground(Color.WHITE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new QuiltPanel(sizeMultiplier));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}
