# cosc326-rg
Red and Green

## Will Shaw - COSC326 S2 - 2017

``` makefile

Compile : make

Test    : make test

Clean   : make clean
```
