/*
    Red and Green Implementation. (No header).
    Will Shaw - COSC326 S2 - 2017
    
    Compile  : make
    Test     : make test
    Clean    : make clean
*/

#include <map>
#include <iostream>
#include <sstream>

using namespace std;

std::map<int, char> known;

/* Recursive function to calculate factors. Checks the map for
   known values instead of having to recalculate every one */
int calc(int val) {
    int fac = 1, acc = 0;
    while (fac <= val / 2) { // Finding factors which reduces the 
    	int d = val / fac; //   problem faster than a brute force loop.
    	if (val / d == fac) {
    		if (known.find(fac) != known.end()) // Check the map for val.
    			if (known.find(fac)->second == 'G') acc += 1;
    			else acc -= 1; // If found and Red, reduce the accumulator.
    		else acc += calc(fac); // Otherwise we need to calc the colour.
    	}
    	fac++;
    }
    known[val] = (acc <= 0) ? 'G' : 'R'; // Add the calced color to the map.
    return (acc <= 0) ? 1 : 0; // Return color for calling func's accumulator.
}

/* Read lines from input stream, on each line calculate the output string. */
int main(int argc, char** argv) {
    string line;
    int i = 0, first = -1, second = -1;

    while (cin >> line) {
        if (cin.eof()) break; // End Of File detected break out.
        if (line[0] != '#' && line.length() > 0) { // Is line empty or comment?
            second = i % 2 != 0 ? stoi(line) : -1; // Save second on ! % 2 index.
            first = i % 2 == 0 ? stoi(line) : first; // Save first on % 2 index.
            if (i % 2 != 0 && i > 0) {
                stringstream out;
                cout << first << " " << second << endl << "# ";
                for (int i = first; i < first + second; i++) 
                    out << ((calc(i) == 1) ? 'G' : 'R');
                cout << out.str() << endl << endl; // Print the output string.
                first = -1; second = -1; i = -1; // Reset vars for next line.
            }
            i++;
        }
    }
    return 0; // Exit
}
