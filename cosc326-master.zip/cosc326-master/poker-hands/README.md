# Will Shaw
# Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
# Just to be thorough:

# Build:
javac *.java

# Run:
java AntsMain < [input_file]
