/** Will Shaw - PokerMain Class
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */
import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PokerMain {

    public static void main(String args[]) {

        Scanner sc = new Scanner(System.in);
        String comment = "^#.*";
        String line;

        while (sc.hasNextLine()) {

            line = sc.nextLine();
            if (!line.isEmpty() && !line.matches(comment)) {
                processLine(line);
            }
        }
        sc.close();
    }

    public static void processLine(String line) {
        String cards[] = null;
        String card = "\\d*[kjqatKJQATcdshCDSH]+";
        
        if (line.contains("/")) {
            cards = line.split("/");
        } else if (line.contains(" ")) {
            cards = line.split(" ");
        } else if (line.contains("-")) {
            cards = line.split("-");
        }

        // If the line used 2 delimiter types, throw away line.
        if (cards == null || cards.length < 5) {
            System.err.println("Invalid: " + line);
        } else {

            SortedMap<String, String> map = new TreeMap<>();

            for (int i = 0; i < cards.length; i++) {
                if (!cards[i].matches(card)) {
                    break;
                }

                Pattern digit = Pattern.compile("(\\d+)?");
                Matcher match = digit.matcher(cards[i]);
                int rank = -1;
                int suitIndex = -1;
                /* Extract the number from the card. If the number is 
                    too large or small, the line is invalid, throw away */
                if (match.find() && match.group(0).length() > 0) {
                    rank = Integer.parseInt(match.group(0));
                    if (rank < 1 || rank > 13) {
                        i = 6;
                        break;
                    }
                } else {

                    switch (cards[i].charAt(0)) {
                    case 'a':
                    case 'A':
                        rank = 1;
                        break;
                    case 't':
                    case 'T':
                        rank = 10;
                        break;
                    case 'j':
                    case 'J':
                        rank = 11;
                        break;
                    case 'q':
                    case 'Q':
                        rank = 12;
                        break;
                    case 'k':
                    case 'K':
                        rank = 13;
                        break;
                    }
                    suitIndex = 1;
                }

                suitIndex = suitIndex == (-1) 
                    ? String.valueOf(rank).length() 
                    : 1;

                Card convertedCard = new Card(rank,
                        String.valueOf(cards[i].charAt(suitIndex))
                        .toUpperCase().charAt(0));

                map.put(convertedCard.value(), convertedCard.toString());

            }
            if (map.values().size() == 5) {
                System.out.println(String.join(" ", map.values()));
            } else {
                // Duplicate card, invalid rank, or invalid suit.
                System.err.println("Invalid: " + line);
            }
        }
    }

}
