/** Will Shaw - Card Class
 * Language: Java version "1.8.0_131" JRE "1.8.0_131-b11"
 */
public class Card {

    private int rank;
    private char suit;

    public Card(int rank, char suit) {
        this.rank = rank;
        this.suit = suit;
    }

    /** Returns a zeroed representation with ACE represented
     * by 14 so it can be easily sorted alphanumerically.
     * This becomes the key in the map.
     */
    public String value() {
        int rankSet = rank == 1 ? 14 : rank;
        String zeroedRank = String.valueOf(rankSet).length() == 1 
            ? "0" + String.valueOf(rankSet)
            : String.valueOf(rankSet);
        return zeroedRank + this.suit;
    }

    /**
     * Returns the desired representation for each card.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        switch (this.rank) {
        case 1:
            sb.append('A');
            break;
        case 10:
            sb.append("10");
            break;
        case 11:
            sb.append('J');
            break;
        case 12:
            sb.append('Q');
            break;
        case 13:
            sb.append('K');
            break;
        default:
            sb.append(String.valueOf(rank));
            break;
        }
        sb.append(suit);
        return sb.toString().toUpperCase();
    }

}
