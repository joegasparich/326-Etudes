/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forsale.strategies;

import forsale.AuctionState;
import forsale.Card;
import forsale.PlayerRecord;
import forsale.SaleState;
import forsale.Strategy;
import java.util.ArrayList;

/**
 *
 * @author dathomson
 */
public class Aggressive implements Strategy{
    
    @Override
    public int bid(PlayerRecord p, AuctionState a) {
        return p.getCash();
    }

    @Override
    public Card chooseCard(PlayerRecord p, SaleState s) {
        ArrayList<Card> cards = p.getCards();
        int highest = 0;
        for(int i = 1; i < cards.size(); i++) {
            if(cards.get(highest).getQuality() < cards.get(i).getQuality()) {
                highest = i;
            }
        }
        return cards.get(highest);
    }
}
