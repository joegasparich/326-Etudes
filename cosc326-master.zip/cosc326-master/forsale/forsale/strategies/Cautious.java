/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forsale.strategies;

import forsale.AuctionState;
import forsale.Card;
import forsale.PlayerRecord;
import forsale.SaleState;
import forsale.Strategy;
import java.util.ArrayList;

/**
 *
 * @author dathomson
 */
public class Cautious implements Strategy{
    
    @Override
    public int bid(PlayerRecord p, AuctionState a) {
        ArrayList<Card> cards = a.getCardsInAuction();
        int highest = cards.get(0).getQuality();
        for(int i = 1; i < cards.size(); i++) {
            if(highest < cards.get(i).getQuality()) {
                highest = cards.get(i).getQuality();
            }
        }
        if(p.getCards().size() == 5) {
            return p.getCash();
        }
        if(highest > 27) {
            return (p.getCash()*3)/4;
        }
        return -1;
    }

    @Override
    public Card chooseCard(PlayerRecord p, SaleState s) {
        ArrayList<Integer> cheques = s.getChequesAvailable();
        int highest = 0;
        int lowest = 0;
        for(int i = 1; i < cheques.size(); i++) {
            if(highest < cheques.get(i)) {
                highest = cheques.get(i);
            }
            if(lowest > cheques.get(i)) {
                lowest = cheques.get(i);
            }
        }
        ArrayList<Card> cards = p.getCards();
        Card highCard = cards.get(0);
        Card lowCard = cards.get(0);
        for(int i = 1; i < cards.size(); i++) {
            if(highCard.getQuality() < cards.get(i).getQuality()) {
                highCard = cards.get(i);
            }
            if(lowCard.getQuality() > cards.get(i).getQuality()) {
                lowCard = cards.get(i);
            }
        }
        if(highest > 12) {
            return highCard;
        }
        if(lowest > 7) {
            return lowCard;
        }
        return cards.get(0);
    }
        
}
