package forsale.strategies;

import forsale.AuctionState;
import forsale.Card;
import forsale.PlayerRecord;
import forsale.SaleState;
import forsale.Strategy;
public class Random implements Strategy {

    @Override
    public int bid(PlayerRecord p, AuctionState a) {
        return (int) (1 + (Math.random()*p.getCash()));
    }

    @Override
    public Card chooseCard(PlayerRecord p, SaleState s) {
        return p.getCards().get((int) (Math.random()*p.getCards().size()));
    }

}
            