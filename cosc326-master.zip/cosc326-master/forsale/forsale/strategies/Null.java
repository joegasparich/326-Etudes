package forsale.strategies;

import forsale.AuctionState;
import forsale.Card;
import forsale.PlayerRecord;
import forsale.SaleState;
import forsale.Strategy;

public class Null implements Strategy {

    @Override
    public int bid(PlayerRecord p, AuctionState a) {
        return -1;
    }

    @Override
    public Card chooseCard(PlayerRecord p, SaleState s) {
        return p.getCards().get(0);
    }

}