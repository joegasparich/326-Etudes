package forsale;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import forsale.GameManager;
import forsale.strategies.Aggressive;
import forsale.strategies.Cautious;
import forsale.strategies.Null;
import forsale.strategies.Random;

/**
 *
 * @author MichaelAlbert
 */
public class Test1000 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int[] playerStats = new int[6];

        for (int i = 0; i < 10000; i++) {

            ArrayList<Player> players = new ArrayList<>();
            players.add(new Player("N", new Null()));
            players.add(new Player("R", new Random()));
            
            players.add(new Player("A", new Aggressive()));
            players.add(new Player("C", new Cautious()));
            
            players.add(new Player("I", new Informed()));
            players.add(new Player("B", new Balanced()));

            Collections.shuffle(players);

            GameManager g = new GameManager(players);    
            g.run();
            
            Scanner scan = new Scanner(g.getLog());
            String line = scan.nextLine();
            String[] winner = null;

            while (scan.hasNextLine()) {
                line = scan.nextLine();
                
                if (line.equals("Final standings:")) {
                    line = scan.nextLine();
                    winner = line.split(" ");
                    break;
                }
            }

            switch (winner[1]) {
                case "A":
                    playerStats[2]++;
                    break;
                case "B":
                    playerStats[5]++;
                    break;
                case "C":
                    playerStats[3]++;
                    break;
                case "I":
                    playerStats[4]++;
                    break;
                case "N":
                    playerStats[0]++;
                    break;
                case "R":
                    playerStats[1]++;
                    break;
            }
        }

        System.out.println(" [N]\t [R]\t [A]\t [C]\t [I]\t [B]\n[" +
                            playerStats[0] + "]\t[" + 
                            playerStats[1] + "]\t[" +
                            playerStats[2] + "]\t[" + 
                            playerStats[3] + "]\t[" +
                            playerStats[4] + "]\t[" +
                            playerStats[5] + "]");

        //System.out.println(g.getLog());
    }

}
