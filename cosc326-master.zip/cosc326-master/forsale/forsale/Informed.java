/**
 * Informed Strategy
 * Team: ‘String teamName = this == winner ? "The Champions" : "We tried";’
 * Members: Daniel Thomson, Duncan Cowan, Will Shaw
 * Java Version: 1.8.0_131
 */
package forsale;

import java.util.ArrayList;
import java.util.Random;

public class Informed implements Strategy {

    private int lowCard = 10;
    private int highCard = 23;
    private int chequeRange = 12;
    private int highCheque = 10;
    private int lowCheque = 4;

    private int handCount = 0;

    /**
     * Makes a bid for a player given the state of the current auction. A return
     * value less than the current bid (or more than the player's cash)
     * indicates that the player is dropping out of the auction.
     *
     * @param p the player
     * @param a the state of the auction
     * @return the bid
     */
    @Override
    public int bid(PlayerRecord p, AuctionState a) {
        // If we are the first player, start with a high bid to attempt 
        // to force bluffs.
        if (a.getPlayersInAuction().get(0).getName()
                .equals(p.getName()) && handCount == 0) {
            if (p.getCash() > 4) {
                return 4;
            }
        }
        if (handCount < 2) {
            // If all players remain in the game, bid small.
            if (a.getPlayersInAuction().size() == a.getPlayers().size()) {
                return a.getCurrentBid() + 1;
            }
        }
        ArrayList cards = a.getCardsInAuction();
        int numLowCards = 0, numHighCards = 0;
        int highestCard = 0;
        for(Object card : cards) {
            if (((Card)card).getQuality() > highestCard) {
                highestCard = ((Card)card).getQuality();
            }
            if (((Card)card).getQuality() <= lowCard) {
                numLowCards++;
            } else if (((Card) card).getQuality() >= highCard) {
                numHighCards++;
            }
        }

        // If the highest card in play is over 25 bid higher.
        if(highestCard > 25) {
            if (p.getCash() > a.getCurrentBid() + 4) {
                return a.getCurrentBid() + 4;
            } else {
                return a.getCurrentBid() + 2;
            }
        }

        // If low cards make up half the auction pass. Just take the low.
        if (numLowCards > a.getCardsInAuction().size() / 2) {
            return -1;
        }
        // If high cards make up half the auction, Attempt a higher bid.
        if (numHighCards > a.getCardsInAuction().size() / 2) {
            if (p.getCash() > 2) {
                return a.getCurrentBid() + 2;
            }
        }
        handCount++;
        return -1;
    }


    /**
     * Chooses a card for a player in the current sale. It is expected that this
     * will be a card which the player holds! If this contract is violated the
     * game management system can choose any one of the player's cards in an
     * arbitrary manner.
     *
     * @param p the player
     * @param s the state of the current sale
     * @return the card which that player will sell in this sale.
     */
    @Override
    public Card chooseCard(PlayerRecord p, SaleState s) {
        int lowestCheque = s.getChequesAvailable().get(0);
        int highestCheque = s.getChequesAvailable().get(0);

        // Save the highest and lowest cheque values.
        for (int cheque : s.getChequesAvailable()) {
            if (cheque > highestCheque) {
                highestCheque = cheque;
            }
            if (cheque < lowestCheque) {
                lowestCheque = cheque;
            }
        }

        // Find the range between highest and lowest.
        int range = highestCheque - lowestCheque;
        int lowestCard = 31;

        // Choose the lowest card to offer.
        if (range < chequeRange) {
            for(int i = 0; i < p.getCards().size(); i++) {
                if (p.getCards().get(i).getQuality() < lowestCard) {
                    lowestCard = i;
                }
            }
            return p.getCards().get(lowestCard);
        }

        // If the highest cheque is above a threshold, bid the first high card.
        if (highestCheque > highCheque) {
            for(Object card : p.getCards()) {
                if (((Card)card).getQuality() > highCard) {
                    return (Card)card;
                }
            }
        }

        // If the highest cheque is low, bid low.
        if (highestCheque < lowCheque) {
            for(Object card : p.getCards()) {
                if (((Card)card).getQuality() < lowCard) {
                    return (Card)card;
                }
            }
        }

        // Otherwise return a random card.
        Random rand  = new Random();
        return p.getCards().get(rand.nextInt(p.getCards().size()));
    }

}
