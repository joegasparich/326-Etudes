/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forsale;

import java.util.ArrayList;

import forsale.strategies.Aggressive;
import forsale.strategies.Balanced;
import forsale.strategies.Cautious;
import forsale.strategies.Informed;
import forsale.strategies.Null;
import forsale.strategies.Random;

/**
 *
 * @author MichaelAlbert
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            
        ArrayList<Player> players = new ArrayList<>();
        players.add(new Player("N", new Null()));
        players.add(new Player("R", new Random()));
        
        players.add(new Player("A", new Aggressive()));
        players.add(new Player("C", new Cautious()));
        
        players.add(new Player("I", new Informed()));
        players.add(new Player("B", new Balanced()));

        GameManager g = new GameManager(players);
        g.run();
        System.out.println(g.getLog());
    }

}
