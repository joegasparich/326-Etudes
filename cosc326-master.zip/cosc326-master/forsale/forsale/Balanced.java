/**
 * Balanced Strategy
 * Team: ‘String teamName = this == winner ? "The Champions" : "We tried";’
 * Members: Daniel Thomson, Duncan Cowan, Will Shaw
 * Java Version: 1.8.0_131
 */
package forsale;

import java.util.ArrayList;

/**
 *
 * @author dathomson
 */
public class Balanced implements Strategy{
    
    @Override
    public int bid(PlayerRecord p, AuctionState a) {
        ArrayList<Card> cards = sortCards(a.getCardsInAuction());
        int maxBid = 0;
        
        //Determin highest and lowest value properties
        int lowest = cards.get(0).getQuality();
        int highest = lowest;
        for(int i = 1; i < cards.size(); i++) {
            if(highest < cards.get(i).getQuality()) {
                highest = cards.get(i).getQuality();
            }
            if(lowest > cards.get(i).getQuality()) {
                lowest = cards.get(i).getQuality();
            }
        }
        
        //If first bid 2
        if(a.getCardsInAuction().size() == 6 && a.getCurrentBid() == 0) {
            return 2;
        }
        
        //If value of lowest property is >= 15, pass
        if(lowest >= 15 && a.getCurrentBid() == 0) {
            return -1;
        }
        
        //Set maximum bid for round based on value of highest property
        if(highest >= 10) {
            maxBid = p.getCash()/4;
        }
        if(highest >= 20) {
            maxBid = p.getCash()/3;
        }
        if(highest >= 27) {
            maxBid = p.getCash()/2;
        }
        
        //Increment bid by one, if bid > maxBid, pass
        int bid = a.getCurrentBid() + 1;
        if(bid <= maxBid) {
            return bid;
        } else {
            return -1;
        }
    }
            
    @Override
    public Card chooseCard (PlayerRecord p, SaleState s) {
        //Predict sale based on highest card from each player
        int[] psr = predictSale(p, s);
        
        //Sort our cards
        ArrayList<Card> cards = sortCards(p.getCards());
        
        //Set return card to lowest value card which is > high card of player in
        // position below us (determined from predictSale).
        Card returnCard = cards.get(cards.size()-1);
        for(int i = cards.size()-2; i > -1; i--) {
            if(cards.get(i).getQuality() > psr[1]) {
                returnCard = cards.get(i);
            } else {
                i = -1;
            }
        }
        
        //If our high card is >= 25 and our position based on predict sale is >
        // 2, set return card to our lowest card (if lowest cheque value is >= 5) or
        // middle value card if there are no 15,14 or 13 value cheques in play.
        if(cards.get(cards.size()-1).getQuality() >= 25 && psr[0] > 2) {
            if(s.getChequesAvailable().get(s.getChequesAvailable().size()-1)
                    < 13) {
                if(s.getChequesAvailable().get(0) >= 5) {
                    returnCard = cards.get(0);
                } else {
                    returnCard = cards.get(cards.size()/2);
                }
            }
        }
        
        //If we have the highest card and a 15 value cheque is avaliable in the deck
        //play our second highest card, if its value is lower than our current return card.
        if(psr[0] == 1 && s.getChequesAvailable().contains(15) == false && s.getChequesRemaining().contains(15) == true) {
            if(returnCard.getQuality() > cards.get(cards.size()-2).getQuality()) {
                returnCard = cards.get(cards.size()-2);
            }
        }
        
        //If lowest cheque is >= 10 play our lowest card
        if(s.getChequesAvailable().get(0) >= 10) {
            returnCard = cards.get(0);
        }
        
        return returnCard;
    }
    
    /**
     * Predict the result of the sale if every player were to play their highest
     * card
     * @param p our player record
     * @param s state of the current sale
     * @return int array, where the first value represents our position in 
     * predicted sale and the second value is the value of the highest card of 
     * the player below us in the predicted sale 
     */
    public int[] predictSale (PlayerRecord p, SaleState s) {
        ArrayList<PlayerRecord> players = s.getPlayers();
        int[] highCards = new int[players.size()];
        
        //Find high cards for each player
        for(int i = 0; i < players.size(); i++) {
            int highCard = 0;
            for(Card c : players.get(i).getCards()) {
                if(c.getQuality() > highCard) {
                    highCard = c.getQuality();
                }
            }
            highCards[i] = highCard;
        }
        
        //Find our high card
        int ownHighCard = 0;
        for(Card c : p.getCards()) {
            if(c.getQuality() > ownHighCard) {
                ownHighCard = c.getQuality();
            }
        }
      
        //Determin our position based on each players high card
        int pos = 0;
        for(int i = 0; i < highCards.length; i++) {
            if(highCards[i] >= ownHighCard) {
                pos++;
            }
        }
        
        //Determin value of high card for player in position below us
        int highBelowOwn = 0;
        for(int i : highCards) {
            if(i > highBelowOwn && i < ownHighCard) {
                highBelowOwn = i;
            }
        }
        
        int[] result = {pos, highBelowOwn};
        return result;
    }
    
    /**
     * Quicksort for sort our hand of cards
     * @param cards hand to be sorted
     * @return sorted hand
     */
    public ArrayList<Card> sortCards (ArrayList<Card> cards) {
        if(cards.size() <= 1) {
            return cards;
        }
        Card pivotC = cards.get(0);
        int pivot = pivotC.getQuality();
        ArrayList<Card> smaller = new ArrayList<>();
        ArrayList<Card> bigger = new ArrayList<>();
        for(Card c : cards) {
            int val = c.getQuality();
            if(val != pivot) {
                if(val > pivot) {
                    bigger.add(c);
                } else {
                    smaller.add(c);
                }
            }
        }
        return addCards(sortCards(smaller), pivotC, sortCards(bigger));
    }
    
    /**
     * Combines array of cards for use in Quicksort
     * @param firstHalve first halve of hand
     * @param p pivot card
     * @param secondHalve second halve of hand
     * @return combined hand
     */
    private ArrayList<Card> addCards (ArrayList<Card> firstHalve, Card p, ArrayList<Card> secondHalve) {
        firstHalve.add(p);
        for (Card c : secondHalve) {
            firstHalve.add(c);
        }
        return firstHalve;
    }
}
