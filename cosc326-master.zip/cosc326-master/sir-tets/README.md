# cosc326-sir-tets
Sir Tet's carpets

## To see only stdout
javac *.java && java Tet < input 2> /dev/null
