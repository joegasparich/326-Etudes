
#ifndef SUPERLONG_HPP_
#define SUPERLONG_HPP_

#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include <cmath>

using namespace std;

class SuperLong {
    private:
        SuperLong();
        SuperLong(vector<int> digits, int sign);

        SuperLong addHelper(vector<int> first, vector<int> second);
        
        SuperLong mulHelper(SuperLong o);

        SuperLong divHelper(SuperLong o);

        SuperLong subHelper(vector<int> first, vector<int> second, int resultSign);

    public:
        vector<int> digits;
        int sign;

        SuperLong(string value);

        SuperLong add(SuperLong o);

        SuperLong subtract(SuperLong o);

        SuperLong multiply(SuperLong o);

        SuperLong divide(SuperLong o);

        SuperLong halve();

        SuperLong gcd(SuperLong o);

        string to_string();

        bool lt(SuperLong o);
        
        bool gt(SuperLong o);
        
        bool eq(SuperLong o);

        void removeZeros();
        
        int compare(SuperLong o);

};

#endif // SUPERLONG_HPP_
