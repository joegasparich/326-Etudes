
#include "superlong.hpp"

SuperLong::SuperLong(string value) {
    sign = 0;
    for (int i = value.length() - 1; i >= 0; i--) {
        if (value.at(i) == '-') {
            sign = 1;
        } else {
            if (!(value.at(i) >= '0' && value.at(i) <= '9')) {
                throw invalid_argument("Syntax error");
            }
            digits.push_back(value.at(i) - '0');
        }
    }
}

SuperLong::SuperLong(vector<int> digits, int sign) {
    this->digits = digits;
    this->sign = sign;
}

string SuperLong::to_string() {
    stringstream ss;
    if (sign == 1) {
        ss << '-';
    }
    for (int i = (int) digits.size() - 1; i >= 0; i--) {
        ss << digits[i];
    }
    return ss.str();
}

SuperLong SuperLong::add(SuperLong o) {

    if (sign + o.sign == 1) {
        sign = (bool) !sign;
        SuperLong ret = subtract(o);
        sign = (bool) !sign;
        ret.sign = (int) !ret.sign;
        return ret;
    }

    if (compare(o) == -1) {
        return addHelper(o.digits, digits);
    }
    return addHelper(digits, o.digits);
}

SuperLong SuperLong::addHelper(vector<int> large, vector<int> small) {
    int carry = 0;
    vector<int> result;
    for (int i = 0; i < large.size(); i++) {
        if (i < small.size()) {
            carry = large[i] + small[i] + carry;
        } else {
            if (large.size() > small.size()) {
                carry += large[i];
            } else {
                carry += small[i];
            }
        }
        if (carry >= 10) {
            carry -= 10;
            result.insert(result.begin(), carry);
            carry = 1;
        } else {
            result.insert(result.begin(), carry);
            carry = 0;
        }
    }
    if (carry > 0) {
        result.insert(result.begin(), carry);   
    }
    reverse(result.begin(), result.end());
    SuperLong ret(result, this->sign);
    ret.removeZeros();
    return ret;
}

SuperLong SuperLong::subtract(SuperLong o) {
    if (sign + o.sign == 1) {
        sign = (bool) !sign;
        SuperLong ret = add(o);
        sign = (bool) !sign;
        ret.sign = (int) !ret.sign;
        if (ret.compare(SuperLong("0")) == 0) { // If mag is 0 sign should be pos.
            ret.sign = 0;
        }
        return ret;
    }

    if (compare(o) == 0) { // If the numbers are equal; pos sign.
        vector<int> result;
        result.push_back(0);
        return SuperLong(result, 0);
    }

    if (compare(o) == -1) { // If the numbers are both the same sign.
        return subHelper(o.digits, digits, (int) !this->sign);
    } else {
        return subHelper(digits, o.digits, this->sign);
    }
}

SuperLong SuperLong::subHelper(vector<int> first, vector<int> second, int resultSign) {
    vector<int> result;
    for(int i = 0; i < first.size(); i++) {
        if(i < second.size()) {
            int v = first[i] - second[i];
            if(v < 0) {
                bool carry = true;
                int c = i;
                while (carry && c < second.size()-1) {
                    second[c+1] += 1;
                    if(second[c+1] == 10) {
                        second[c+1] = 0;
                        c++;
                    } else {
                        carry = false;
                    }
                }
                if (carry) {
                    second.insert(second.end(), 1);
                }
                v = 10 + v;
            }
            result.insert(result.begin(), v);
        } else {
            result.insert(result.begin(), first[i]);
        }
    }
    reverse(result.begin(), result.end());
    SuperLong ret(result, resultSign);
    ret.removeZeros();
    return ret;
}

void SuperLong::removeZeros() {
    for(int i = digits.size() - 1; i >= 0; i--) {
        if (digits[i] != 0) {
            break;
        } else {
            digits.erase(digits.end()- 1);
        }
    }
}

SuperLong SuperLong::halve() {
    vector<int> result;
    for(int i = 0; i < digits.size(); i++) {
        result.insert(result.begin(), digits[i]/2);
        if(digits[i]%2 != 0 && i != 0) {
            result[1] = (int)(result[1] + 5);
        }
    }
    reverse(result.begin(), result.end());
    SuperLong ret(result, this->sign);
    ret.removeZeros();
    return ret;
}

SuperLong SuperLong::multiply(SuperLong o) {
    SuperLong ret = mulHelper(o);
    
    if (sign + o.sign == 2 || sign + o.sign == 0) {
        ret.sign = 0;
        return ret;
    }
    ret.sign = 1;
    return ret;
}

SuperLong SuperLong::mulHelper(SuperLong o) {
    SuperLong result = SuperLong("0");
    SuperLong halveO = SuperLong("0");
    SuperLong zero = SuperLong("0");
    SuperLong one = SuperLong("1");
    SuperLong self = SuperLong(this->digits, 0);
    if(o.compare(zero) == 0 || self.compare(zero) == 0) {
        return zero;
    }
    if(o.compare(one) != 0) {
        halveO = o.halve();
        if(o.digits[0]%2 == 0) {
            result = self.mulHelper(halveO);
            result = result.add(result);
        } else {
            result = self.mulHelper(halveO);
            result = result.add(result);
            result = result.add(self);
        }
    } else {
        result = self;
    }
    return result;
}

SuperLong SuperLong::divide(SuperLong o) {
    SuperLong ret = divHelper(o);
    
    if (sign + o.sign == 2 || sign + o.sign == 0) {
        ret.sign = 0;
        return ret;
    }
    ret.sign = 1;
    return ret;
}

SuperLong SuperLong::divHelper(SuperLong o) {
    SuperLong result = SuperLong("0");
    SuperLong doubleO = SuperLong(o.digits, o.sign);
    SuperLong prv = SuperLong("0");
    SuperLong zero = SuperLong("0");
    SuperLong one = SuperLong("1");
    SuperLong self = SuperLong(this->digits, 0);
    while (self.compare(doubleO) == 1) {
        if(result.compare(zero) == 0) {
            result = result.add(one);
        } else {
            result = result.add(result);
        }
        prv.digits = doubleO.digits;
        doubleO = doubleO.add(doubleO);
    }
    if(self.compare(doubleO) == 0) {
        if(result.compare(zero) == 0) {
            result = result.add(one);
        } else {
            result = result.add(result);
        }
        return result;
    } else {
        if(result.compare(zero) == 0) {
            return result;
        }
        result = result.add((self.subtract(prv)).divHelper(o));
    }
    return result;
}

SuperLong SuperLong::gcd(SuperLong o) {
    SuperLong a(to_string());
    SuperLong b(o.to_string());
    SuperLong g("0");

    int d = 0;
    while (a.digits[0] % 2 == 0 && b.digits[0] % 2 == 0) {
        a = a.halve();
        b = b.halve();
        d++;
    }

    while (a.compare(b) != 0) {
        if (a.digits[0] % 2 == 0) {
            a = a.halve();
        } else if (b.digits[0] % 2 == 0) {
            b = b.halve();
        } else if (a.compare(b) > 0) {
            a = a.subtract(b).halve();
        } else {
            b = b.subtract(a).halve();
        }
    }
    g = a;
    SuperLong two("2");

    int t = pow(2, d);

    SuperLong h(std::to_string(t)); 

    for (int i = 0; i < d; i++) {
        h.multiply(two);
    }
    g.sign = 0;
    return g.multiply(h);
}

int SuperLong::compare(SuperLong o) {
    if (digits.size() == o.digits.size()) {
        for (int i = digits.size() - 1; i >= 0; i--) {
            if (digits[i] != o.digits[i]) {
                return digits[i] > o.digits[i] ? 1 : -1;
            }
        }
        return 0;
    }
    return (digits.size() > o.digits.size() ? 1 : -1);
}

bool SuperLong::lt(SuperLong o) {
    if (sign == o.sign) {
        return compare(o) == -1;
    } else {
        return sign > o.sign;
    }
}

bool SuperLong::gt(SuperLong o) {
    if (sign == o.sign) {
        return compare(o) == 1;
    } else {
        return sign < o.sign;
    }
}

bool SuperLong::eq(SuperLong o) {
    if (sign == o.sign) {
        return compare(o) == 0;
    }
    return false;
}

