
#include <iostream>
#include "superlong.hpp"

using namespace std;

void output(string first, string op, string second) {
    SuperLong f(first);
    SuperLong s(second);
    switch (op[0]) {
        case '+':
            cout << "# " << f.add(s).to_string();
            break;
        case '-':
            cout << "# " << f.subtract(s).to_string();
            break;
        case '<':
            cout << "# " << ((f.lt(s) == 0) ? "false" : "true");
            break;
        case '>':
            cout << "# " << ((f.gt(s) == 0) ? "false" : "true");
            break;
        case '=':
            cout << "# " << ((f.eq(s) == 0) ? "false" : "true");
            break;
        case '*':
            cout << "# " << f.multiply(s).to_string();
            break;
        case '/':
            SuperLong di = f.divide(s);
            cout << "# " << di.to_string();
            cout << " " << f.subtract(di.multiply(s)).to_string();
            break;
    }
    
    if (op == "gcd") {
        cout << "# " << f.gcd(s).to_string();
    }

    cout << endl << endl;
}

int main(int argc, char** argv) {
    string line;
    
    string first, second;
    string op;

    while (getline(cin, line)) {
        int currentToken = 0;
        if (line[0] != '#' && line.length() > 0) { // Is line empty or comment?
            cout << line << endl;
            stringstream ss(line);
            string token;
            while (ss >> token) {
                if (currentToken == 0) {
                    first = token;
                } else if (currentToken == 1) {
                    op = token;
                } else if (currentToken == 2) {
                    second = token;
                }
                currentToken++;
            }
            if (currentToken == 3) {
                try {
                    output(first, op, second);
                } catch (const invalid_argument &e) {
                    cout << "# " << e.what() << endl << endl;
                }
            } else {
                // In other cases, (including if where we have too many tokens), error.
                cout << "# Syntax error" << endl << endl;
            }
        }
    }
    return 0; // Exit
}
