var points = [];

const borderSize = 50;
const graphHeight = 1000;

var bestIncrease = 0;
var currentHigh = -1;
var currentLow = -1;

var goalDistance;
var lastPointX;
var lastPointY;
var modifier;

var bestLowIndex = 0;
var bestHighIndex = 0;
var lowIndex = -1;
var highIndex = -1;

var currentIndex = 0;

function load() {

    currentIndex = 0;
    points = [];
    bestIncrease = 0;
    currentLow = 0;
    currentHigh = 0;
    bestLowIndex = 0;
    bestHighIndex = 0;
    lowIndex = -1;
    highIndex = -1;

    redraw();

    var lines = document.getElementById('points').value.split('\n');

    lines.forEach((line) => {
        if (line.match(new RegExp('^#.*'))) {
            console.log(line);
        } else if (!(line.length === 0)) {

            var spaceSplit = line.split(',');

            if (spaceSplit.length > 1) {
                spaceSplit.forEach((item) => {
                    if (item.length > 1) {
                        addPoint(item);
                    }
                });
            } else {
                addPoint(line);
            }
        }
    });

    inform('Loaded');

    graph();
}

function addPoint(digit) {
    if (digit.trim().match(new RegExp('^(-)?\\d+$'))) {
        points.push(new Number(digit));
    } else {
        console.log("NaN");
    }
}

function inform(message, timeout) {
    if (!timeout) timeout = 1000;

    if (document.getElementsByClassName('alert').length > 0) {
        document.getElementsByClassName('alert')[0].remove();
    }

    var node = document.createElement('div');
    var h2 = document.createElement('h2');
    var text = document.createTextNode(message);
    node.className = "alert";
    h2.appendChild(text);
    node.appendChild(h2);
    document.getElementById('alert-container').appendChild(node);

    setTimeout(() => {
        document.getElementsByClassName('alert')[0].className += " alert-active";

        setTimeout(() => {
            document.getElementsByClassName('alert')[0].className = " alert";
        }, timeout);
    }, 100);
}

function graph() {

    currentLow = points[0];
    currentHigh = points[0];

    var slowDraw = setInterval(() => {

        if (currentIndex < points.length) {

            if (points[currentIndex] <= currentLow) {
                currentLow = points[currentIndex];
                currentHigh = points[currentIndex];
                lowIndex = currentIndex;
                highIndex = currentIndex;
            }
            if (points[currentIndex] <= currentLow) {
                document.getElementById('currentLow').value = points[currentIndex];
                currentLow = points[currentIndex];
                lowIndex = currentIndex;
            }
            if (points[currentIndex] > currentHigh) {
                document.getElementById('currentHigh').value = points[currentIndex];
                currentHigh = points[currentIndex];
                highIndex = currentIndex;
            }
            if (currentHigh - currentLow > bestIncrease) {
                bestHighIndex = highIndex;
                bestLowIndex = lowIndex;
                bestIncrease = currentHigh - currentLow;
                document.getElementById('bestIncrease').value = bestIncrease;
            }
            currentIndex++;
            redraw();
        } else {
            clearInterval(slowDraw);
            inform('Done');
            redraw();
        }
    }, 1);
}

function redraw() {

    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    goalDistance = points.length - 1;
    lastPointX = borderSize;
    lastPointY = points[0];
    modifier = (canvas.width - (borderSize * 2)) / goalDistance;

    ctx.strokeStyle = '#aaa';
    ctx.lineWidth = 3;

    ctx.beginPath();
    ctx.moveTo(borderSize, graphHeight);
    ctx.lineTo(borderSize + (points.length - 1) * modifier, graphHeight);
    ctx.stroke();

    for (var i = 0; i < points.length; i++) {

        if (i > lowIndex && i <= highIndex) {
            ctx.strokeStyle = "#10bc52";
        } else {
            ctx.strokeStyle = "#aaa";
        }

        if (i > currentIndex && i <= currentIndex + 1) {
            ctx.strokeStyle = "#0055ff";            
        }

        if (i > bestLowIndex && i <= bestHighIndex) {
            ctx.strokeStyle = "#ff0000";            
        }

        ctx.beginPath();
        ctx.moveTo(lastPointX, graphHeight - lastPointY);
        ctx.lineTo(borderSize + i * modifier, graphHeight - points[i]);
        ctx.stroke();
        lastPointX = borderSize + i * modifier;
        lastPointY = points[i];
    }

    ctx.strokeStyle = "#0055ff";
    ctx.fillStyle = "#0055ff";
    ctx.font = "26px Arial";

    ctx.beginPath();
    ctx.moveTo(borderSize, graphHeight - points[bestHighIndex]);
    ctx.lineTo(borderSize + (points.length - 1) * modifier, graphHeight - points[bestHighIndex]);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(borderSize, graphHeight - points[bestLowIndex]);
    ctx.lineTo(borderSize + (points.length - 1) * modifier, graphHeight - points[bestLowIndex]);
    ctx.stroke();

    ctx.fillText(points[bestHighIndex], borderSize + 20 + bestHighIndex * modifier, graphHeight - points[bestHighIndex] + 25);
    ctx.fillText(points[bestLowIndex], borderSize + 20 + bestLowIndex * modifier, graphHeight - points[bestLowIndex] - 5);
}