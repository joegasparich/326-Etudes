var commands = [];
var commandIndex = 0;
var truck = new Truck();
var sim;
var simulating = false;

function Truck() {
    this.totalFuelInDesert = 0;
    this.currentCommand = "";
    this.fuelInTank = 0;
    this.fuelInReserve = 0;
    this.distanceFromBase = 0;
    this.totalDistanceDriven = 0;
    this.totalFuelUsed = 0;
    this.farthestDistanceReached = 0;
    this.minTank = 0;
    this.maxTank = 0;
    this.minReserve = 0;
    this.maxReserve = 0;
    this.sites = {
        0: Infinity,
    };

    this.tank = function(quantity) {
        this.currentCommand = "Tank: " + quantity;
        if (!this.sites[this.distanceFromBase]) {
            return "No fuel at this location!";
        }
        this.sites[this.distanceFromBase] = (this.sites[this.distanceFromBase] - quantity);
        this.fuelInTank += quantity;
        if (this.distanceFromBase > 0.0) {
            this.totalFuelInDesert -= quantity;
        }
    }

    this.dump = function(quantity) {
        this.currentCommand = "Dump: " + quantity;
        if (this.sites[this.distanceFromBase]) {
            this.sites[this.distanceFromBase] = (this.sites[this.distanceFromBase] + quantity);
        } else {
            this.sites[this.distanceFromBase] = quantity;
        }
        this.fuelInReserve -= quantity;
        if (this.distanceFromBase > 0.0) {
            this.totalFuelInDesert += quantity;
        }
    }

    this.cans = function(quantity) {
        this.currentCommand = "Load: " + quantity;
        if (!this.sites[this.distanceFromBase]) {
            return "No fuel at this location!";
        }
        this.sites[this.distanceFromBase] = (this.sites[this.distanceFromBase] - quantity);
        this.fuelInReserve += quantity;
        if (this.distanceFromBase != 0.0) {
            this.totalFuelInDesert -= quantity;
        }
    }

    this.drive = function(distance, direction) {
        this.currentCommand = "Drive: " + distance + " " + direction;
        this.fuelInTank -= (distance / 12.0);
        this.totalFuelUsed += (distance / 12.0);

        if (direction == 'F') {
            this.distanceFromBase += distance;
            this.totalDistanceDriven += distance;

            if (this.distanceFromBase > this.farthestDistanceReached) {
                this.farthestDistanceReached = this.distanceFromBase;
            }

        } else if (direction == 'B') {
            if (this.distanceFromBase == 0) {
                return "Already at base!";
            }
            this.distanceFromBase -= distance;
            this.totalDistanceDriven += distance;
        }
    }

    this.toString = function() {
        return "The Truck used " + this.totalFuelUsed +
            " litres of fuel to drive " + this.totalDistanceDriven +
            " kilometers total.\nThe farthest distance from base was " +
            this.farthestDistanceReached + " kilometers.\nThere was " +
            this.totalFuelInDesert + " litres of fuel left in the desert.";
    }

}

function parseInput() {

    commands = [];

    var firstLine = true;

    var lines = document.getElementById('procedure').value.split('\n');

    lines.forEach((line) => {

        if (firstLine) {
            firstLine = false;
        } else {

            if (line.match(new RegExp('^#.*'))) {
                commands.push(line);
            } else if (line.match(new RegExp('^\\\*\\d.'))) {
                inform('Repeat command not implemented. Please expand any repeats', 3000);
            } else if (!(line.length === 0)) {

                var spaceSplit = line.split(' ');

                if (spaceSplit.length > 1) {
                    spaceSplit.forEach((item) => {
                        if (item.length > 1) {
                            commands.push(item);
                        }
                    });
                } else {
                    commands.push(line);
                }
            }
        }
    }, this);

    truck = new Truck();
    commandIndex = 0;

    inform('Loaded');
}

function inform(message, timeout) {
    if (!timeout) timeout = 1000;

    if (document.getElementsByClassName('alert').length > 0) {
        document.getElementsByClassName('alert')[0].remove();
    }

    var node = document.createElement('div');
    var h2 = document.createElement('h2');
    var text = document.createTextNode(message);
    node.className = "alert";
    h2.appendChild(text);
    node.appendChild(h2);
    document.getElementById('alert-container').appendChild(node);

    setTimeout(() => {
        document.getElementsByClassName('alert')[0].className += " alert-active";

        setTimeout(() => {
            document.getElementsByClassName('alert')[0].className = " alert";
        }, timeout);
    }, 100);
}

function step(index) {
    var cmd = null;

    if (commands.length > index && index >= 0) {
        cmd = commands[index];
    } else {
        clearInterval(sim);
        simulating = false;
        document.getElementById('run').innerText = simulating ? "Stop" : "Run";
        return;
    }

    var result = null;

    var value = new Number(cmd.substring(1));
    switch (cmd.charAt(0)) {
        case 'T':
            result = truck.tank(value);
            if (truck.fuelInTank > truck.maxTank) {
                truck.maxTank = truck.fuelInTank;
            }
            break;
        case 'C':
            result = truck.cans(value);
            if (truck.fuelInReserve > truck.maxReserve) {
                truck.maxReserve = truck.fuelInReserve;
            }
            break;
        case 'F':
            result = truck.drive(value, 'F');
            if (truck.fuelInTank < truck.minTank) {
                truck.minTank = truck.fuelInTank;
            }
            break;
        case 'D':
            result = truck.dump(value);
            if (truck.fuelInReserve < truck.minReserve) {
                truck.minReserve = truck.fuelInReserve;
            }
            break;
        case 'B':
            result = truck.drive(value, 'B');
            if (truck.fuelInTank < truck.minTank) {
                truck.minTank = truck.fuelInTank;
            }
            break;
        case '#':
            var output = truck.toString();
            output += "\nThe file expected " +
                value + " litres of fuel to be used.";
            document.getElementById('result').innerText = output;
            document.getElementsByClassName('result')[0].hidden = false;
            break;
        default:
            simulating = false;
            clearInterval(sim);
            document.getElementById('run').innerText = simulating ? "Stop" : "Run";
            inform("Invalid command: (Command: " + (commandIndex + 1) + ") " + cmd, 3000);
            break;
    }

    document.getElementById('distance').value = roundTo(truck.distanceFromBase, 3);
    document.getElementById('tank').value = roundTo(truck.fuelInTank, 3);
    document.getElementById('reserve').value = roundTo(truck.fuelInReserve, 3);
    document.getElementById('minTank').value = roundTo(truck.minTank, 3);
    document.getElementById('maxTank').value = roundTo(truck.maxTank, 3);
    document.getElementById('minReserve').value = roundTo(truck.minReserve, 3);
    document.getElementById('maxReserve').value = roundTo(truck.maxReserve, 3);
    document.getElementById('command').value = truck.currentCommand;
    redraw();
}

function simulate() {
    if (commands.length == 0 || commandIndex >= commands.length) {
        parseInput();
    }
    clearInterval(sim);
    if (!simulating) {
        sim = setInterval(() => {
            step(commandIndex++);
        }, new Number(document.getElementById('speed').value));
    }
    document.getElementById('run').innerText = simulating ? "Run" : "Stop";
    simulating = !simulating;
}

function hideResult() {
    document.getElementsByClassName('result')[0].hidden = true;
}

function redraw() {
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    var borderSize = 50;
    var goalDistance = 2413;
    var lastPoint = borderSize;
    var modifier = (canvas.width - (borderSize * 2)) / goalDistance;

    ctx.fillStyle = "#333333";
    ctx.font = "26px Arial";
    ctx.fillText("Distance (km)", borderSize, 180);
    ctx.fillText("Fuel (litres)", borderSize, 420);

    ctx.fillStyle = "#111111";
    ctx.strokeStyle = "#111111";
    ctx.font = "32px Arial";

    Object.keys(truck.sites).forEach((key) => {
        ctx.fillText(roundTo(key, 3), (borderSize - 15) + (key * modifier), 100);

        ctx.beginPath();
        ctx.arc(borderSize + (key * modifier), 300, 10, 0, 2 * Math.PI);
        ctx.fill();

        if (truck.sites[key] == Infinity) {
            ctx.fillText('\u221E', (borderSize - 20) + (key * modifier), 500);
        } else {
            ctx.fillText(roundTo(truck.sites[key], 3), (borderSize - 20) + (key * modifier), 500);
        }
    });

    ctx.fillText(goalDistance, ((borderSize - 30) + goalDistance * modifier), 100);

    ctx.fillStyle = "#009e17";

    ctx.beginPath();
    ctx.arc(borderSize + (goalDistance * modifier), 300, 10, 0, 2 * Math.PI);
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(lastPoint, 300);
    ctx.lineTo(borderSize + truck.distanceFromBase * modifier, 300);
    ctx.stroke();

    ctx.fillStyle = "#0e377a";

    ctx.fillRect((borderSize - 20) + truck.distanceFromBase * modifier, 285, 40, 30);
}

/** @function author Shura on stack overflow : 
 * https://stackoverflow.com/questions/10015027/javascript-tofixed-not-rounding/32605063#32605063 */
function roundTo(n, digits) {
    if (digits === undefined) {
        digits = 0;
    }

    var multiplicator = Math.pow(10, digits);
    n = parseFloat((n * multiplicator).toFixed(11));
    return Math.round(n) / multiplicator;
}