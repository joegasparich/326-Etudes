/** Will Shaw - 2017 */

import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ControlPanel extends JPanel {

    private javax.swing.JButton btnRun;
    private javax.swing.JButton btnStep;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private DrawPanel drawPanel;
    private javax.swing.JTextField txtSpeed;
    private javax.swing.JTextField txtGoal;
    private javax.swing.JCheckBox chkAnimate;

    private boolean play = false;
    private boolean animate = false;
    private boolean animComplete = true;

    private ArrayList<String> cmds = new ArrayList<>();

    private int currentStep = 0;

    private TruckSimple truck;

    public ControlPanel() {
        readInput();
        initComponents();
    }

    private void readInput() {
        Scanner sc = new Scanner(System.in);

        String comment = "^#.*";

        String repeat = "^\\*.*";

        String line = sc.nextLine();

        truck = new TruckSimple();

        while (sc.hasNextLine()) {
            line = sc.nextLine();

            if (line.matches(repeat)) {
                JOptionPane.showMessageDialog(null, 
                    "Repeat not yet implemented!");
                System.exit(1);
            } else if (!line.isEmpty() || line.matches(comment)) {
                cmds.add(line);
            } else {
                JOptionPane.showMessageDialog(null, 
                    "Empty lines break error line detection.");
            }
        }
        sc.close();
    }

    public void step() {
        String cmd = null;
        if (this.cmds.size() > currentStep && currentStep >= 0) {
            cmd = cmds.get(currentStep);
        } else {
            JOptionPane.showMessageDialog(null, "End of commands!");
            play = false;
            btnRun.setText("Run");
            return;
        }

        String result = null;
        Double fromLoc = null;

        double value = Double.parseDouble(cmd.substring(1));
        switch (cmd.charAt(0)) {
        case 'T':
            result = truck.tank(value);
            break;
        case 'C':
            result = truck.cans(value);
            break;
        case 'F':
            fromLoc = TruckSimple.getDistanceFromBase();
            result = truck.drive(value, 'F');
            break;
        case 'D':
            result = truck.dump(value);
            break;
        case 'B':
            fromLoc = TruckSimple.getDistanceFromBase();
            result = truck.drive(value, 'B');
            break;
        case '#':
            StringBuilder sb = new StringBuilder();
            sb.append(truck.toString());
            sb.append("\nThe file expected " + 
                value + " litres of fuel to be used.");
            JOptionPane.showMessageDialog(null, sb.toString());
            truck = truck.reset();
            break;
        default:
            JOptionPane.showMessageDialog(null, "Invalid command: (Command: "
                 + (truck.getCommandCount() + 1) + ")");
            System.exit(1);
            break;
        }

        if (result != null) {
            JOptionPane.showMessageDialog(null, result + 
                "\n(Command " + truck.getCommandCount() + ")");
        }

        if (fromLoc != null && animate) {
            double toLoc = TruckSimple.getDistanceFromBase();
            TruckSimple.setDistanceFromBase(fromLoc);

            int userSpeed = 500;

            try {
                userSpeed = Integer.parseInt(txtSpeed.getText());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, 
                    "Speed requires an integer.");
                play = false;
            }

            double stepSize = (toLoc - fromLoc) / userSpeed;

            Thread anim = new Animator(stepSize, toLoc);
            anim.start();
        }

    }

    private void initComponents() {

        btnRun = new javax.swing.JButton();
        btnStep = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtSpeed = new javax.swing.JTextField();
        drawPanel = new DrawPanel();
        txtGoal = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        chkAnimate = new javax.swing.JCheckBox();

        setBackground(Color.white);
        chkAnimate.setBackground(Color.white);

        btnRun.setText("Run");
        btnRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRunActionPerformed(evt);
            }
        });

        btnStep.setText("Step Foward");
        btnStep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStepActionPerformed(evt);
            }
        });

        jLabel1.setText("Speed");

        txtSpeed.setText("500");

        txtGoal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGoal.setText("2413.0");
        txtGoal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGoalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout drawPanelLayout = 
            new javax.swing.GroupLayout(drawPanel);
        drawPanel.setLayout(drawPanelLayout);
        drawPanelLayout.setHorizontalGroup(
            drawPanelLayout.createParallelGroup(
                    javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, 
                drawPanelLayout.createSequentialGroup()
                .addContainerGap(
                    javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtGoal, 
                    javax.swing.GroupLayout.PREFERRED_SIZE, 49, 
                    javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        drawPanelLayout.setVerticalGroup(
            drawPanelLayout.createParallelGroup(
                    javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(drawPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtGoal, javax.swing.GroupLayout.PREFERRED_SIZE,
                     javax.swing.GroupLayout.DEFAULT_SIZE, 
                     javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(362, Short.MAX_VALUE))
        );

        jLabel2.setText("Animate");

        chkAnimate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkAnimateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(
                javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(
                    javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(drawPanel, 
                        javax.swing.GroupLayout.DEFAULT_SIZE, 
                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnRun)
                        .addPreferredGap(
                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1)
                        .addPreferredGap(
                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtSpeed, 
                            javax.swing.GroupLayout.PREFERRED_SIZE, 50, 
                            javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(
                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(
                        javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(chkAnimate)
                        .addPreferredGap(
                            javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                             222, Short.MAX_VALUE)
                        .addComponent(btnStep)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(
                javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(drawPanel, javax.swing.GroupLayout.DEFAULT_SIZE,
                    javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(
                    javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(
                    javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRun)
                    .addComponent(btnStep)
                    .addComponent(jLabel1, 
                        javax.swing.GroupLayout.PREFERRED_SIZE, 23, 
                        javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSpeed, 
                        javax.swing.GroupLayout.PREFERRED_SIZE, 23, 
                        javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, 
                        javax.swing.GroupLayout.DEFAULT_SIZE, 
                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chkAnimate, 
                        javax.swing.GroupLayout.PREFERRED_SIZE, 23,
                        javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(800, 400);
    }

    private void btnRunActionPerformed(java.awt.event.ActionEvent evt) {
        play = !play;
        if (btnRun.getText() == "Run") {
            btnRun.setText("Stop");
        } else {
            btnRun.setText("Run");
        }
        Thread sim = new Simulator();
        sim.start();
    }

    private void btnStepActionPerformed(java.awt.event.ActionEvent evt) {
        step();
        currentStep++;
        drawPanel.repaint();
    }

    private void chkAnimateActionPerformed(java.awt.event.ActionEvent evt) {
        animate = !animate;
    }

    private void txtGoalActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            double goal = Double.parseDouble(txtGoal.getText());
            drawPanel.setGoal(goal);
            drawPanel.repaint();        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Goal must be a double.");
            play = false;
        }
    }

    private class Simulator extends Thread {

        @Override
        public void run() {
            while (play) {
                while (!animComplete) {
                    try {
                        Thread.sleep(10);
                    } catch (Exception e) {
                    }
                }
                step();
                currentStep++;
                drawPanel.repaint();
                try {
                    Thread.sleep(Integer.parseInt(txtSpeed.getText()));
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, 
                        "Speed requires an integer.");
                    play = false;
                }
            }
        }

    }

    private class Animator extends Thread {

        private double toLoc;
        private double stepSize;

        public Animator(double stepSize, double toLoc) {
            this.toLoc = toLoc;
            this.stepSize = stepSize;
        }

        @Override
        public void run() {
            animComplete = false;
            if (stepSize > 0) {
                while (TruckSimple.getDistanceFromBase() < toLoc) {
                    TruckSimple.setDistanceFromBase(
                        TruckSimple.getDistanceFromBase() + stepSize);
                    drawPanel.repaint();
                    try {
                        Thread.sleep(1);
                    } catch (Exception e) {
                    }
                }
            } else {
                while (TruckSimple.getDistanceFromBase() > toLoc) {
                    TruckSimple.setDistanceFromBase(
                        TruckSimple.getDistanceFromBase() + stepSize);
                    drawPanel.repaint();
                    try {
                        Thread.sleep(1);
                    } catch (Exception e) {
                    }
                }
            }
            TruckSimple.setDistanceFromBase(toLoc);
            animComplete = true;
        }

    }

}
