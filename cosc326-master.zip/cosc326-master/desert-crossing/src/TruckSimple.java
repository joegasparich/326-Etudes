/** Will Shaw - 2017 */

import java.util.HashMap;

public class TruckSimple {

    /* For debugging purposes, monitors current command. */
    private int commandCount = 1;

    /* This shows the state of the desert. */
    private double totalFuelInDesert = 0.0;

    /* This is the current status of the truck. */

    private static String currentCommand;

    private static double fuelInTank = 0.0;

    private static double fuelInReserve = 0.0;

    private static double distanceFromBase = 0.0;

    /* Never decrement these values. */
    private double totalDistanceDriven = 0.0;

    private double totalFuelUsed = 0.0;

    private double farthestDistanceReached = 0.0;

    /* Contains all points where fuel has been dropped. */
    public static HashMap<Double, Double> sites = new HashMap<>();

    public TruckSimple() {
        sites.put(distanceFromBase, 999999999.9);
    }

    public TruckSimple(int commands) {
        this();
        this.commandCount = commands;
    }

    public String tank(double quantity) {
        currentCommand = "Tank: " + quantity;
        this.commandCount++;
        if (sites.get(distanceFromBase) == null) {
            return "No fuel at this location!";
        }
        double fuelAtSite = sites.get(distanceFromBase);
        fuelInTank += quantity;
        sites.put(distanceFromBase, fuelAtSite - quantity);
        if (distanceFromBase > 0.0) {
            this.totalFuelInDesert -= quantity;
        }
        return null;
    }

    public String dump(double quantity) {
        currentCommand = "Dump: " + quantity;
        this.commandCount++;
        if (sites.get(distanceFromBase) != null) {
            sites.put(distanceFromBase, 
                sites.get(distanceFromBase) + quantity);
        } else {
            sites.put(distanceFromBase, quantity);
        }
        fuelInReserve -= quantity;
        if (distanceFromBase > 0.0) {
            this.totalFuelInDesert += quantity;
        }
        return null;
    }

    public String cans(double quantity) {
        currentCommand = "Cans: " + quantity;        
        this.commandCount++;
        if (sites.get(distanceFromBase) == null) {
            return "No fuel at this location!";
        }
        double fuelAtSite = sites.get(distanceFromBase);
        sites.put(distanceFromBase, fuelAtSite - quantity);
        fuelInReserve += quantity;
        if (distanceFromBase > 0.0) {
            this.totalFuelInDesert -= quantity;
        }
        fuelAtSite = sites.get(distanceFromBase);
        if (fuelAtSite == 0.0) {
            sites.remove(distanceFromBase);
        }
        return null;
    }

    public String drive(double distance, char direction) {
        currentCommand = "Drive: " + distance + " " + direction;        
        this.commandCount++;
        fuelInTank -= (distance / 12.0);
        this.totalFuelUsed += (distance / 12.0);

        if (direction == 'F') {
            distanceFromBase += distance;
            this.totalDistanceDriven += distance;

            if (distanceFromBase > this.farthestDistanceReached) {
                this.farthestDistanceReached = distanceFromBase;
            }

        } else if (direction == 'B') {
            if (distanceFromBase == 0) {
                return "Already at base!";
            }
            distanceFromBase -= distance;
            this.totalDistanceDriven += distance;
        }
        return null;
    }

    public int getCommandCount() {
        return this.commandCount;
    }

    public void incrementCommand() {
        this.commandCount++;
    }

    public static double getDistanceFromBase() {
        return distanceFromBase;
    }

    public static void setDistanceFromBase(double distance) {
        distanceFromBase = distance;
    }

    public static double getFuelInTank() {
        return fuelInTank;
    }

    public static double getFuelInReserve() {
        return fuelInReserve;
    }

    public static String getCurrentCommand() {
        return currentCommand;
    }

    public TruckSimple reset() {
        fuelInReserve = 80.0;
        fuelInTank = 60.0;
        distanceFromBase = 0.0;
        return new TruckSimple(commandCount + 1);
    } 

    @Override
    public String toString() {
        return "The Truck used " + totalFuelUsed + 
            " litres of fuel to drive " + totalDistanceDriven + 
            " kilometers total.\nThe farthest distance from base was " + 
            farthestDistanceReached + " kilometers.\nThere was " + 
            totalFuelInDesert + " litres of fuel left in the desert.";
    }

}