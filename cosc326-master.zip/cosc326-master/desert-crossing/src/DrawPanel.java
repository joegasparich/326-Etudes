/** Will Shaw - 2017 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JPanel;

public class DrawPanel extends JPanel {

    private double goalDistance = 2413.0;

    private double modifier;

    private int borderSize = 50;

    private int paddingTop = 200;

    public DrawPanel() {
        setBackground(new java.awt.Color(255, 255, 255));
    }

    public void setGoal(double goal) {
        this.goalDistance = goal;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        modifier = (this.getSize().width - (borderSize * 2)) / goalDistance;

        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
            RenderingHints.VALUE_ANTIALIAS_OFF);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, 
            RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);

        g2d.setColor(Color.black);
        g2d.setFont(new Font("Arial", Font.PLAIN, 16));

        g2d.drawRect(borderSize, borderSize, 300, 100);

        String dist = String.valueOf(TruckSimple.getDistanceFromBase());
        if (dist.length() > 10) {
            dist = dist.substring(0, 10);
        }

        g2d.drawString(" = Truck", borderSize + 20, borderSize - 5);

        g2d.drawString("Distance from base: " + dist, 
            borderSize + 10, borderSize + 25);
        g2d.drawString("Fuel in tank: " + TruckSimple.getFuelInTank(), 
            borderSize + 10, borderSize + 55);
        g2d.drawString("Fuel in reserve: " + TruckSimple.getFuelInReserve(), 
            borderSize + 10, borderSize + 85);
        g2d.drawString("Action: " + TruckSimple.getCurrentCommand(), (int) 
            (((borderSize - 200) + goalDistance * modifier)), borderSize + 60);

        double lastPoint = 50;

        g2d.setFont(new Font("Arial", Font.PLAIN, 12));
        
        g2d.drawString("Distance (km)", (borderSize - 5), 
            (int) (paddingTop * 0.9));
        g2d.drawString("Fuel (litres)", (borderSize - 5), 
            (int) (paddingTop * 1.4));

        g2d.setFont(new Font("Arial", Font.PLAIN, 16));

        for (Double key : TruckSimple.sites.keySet()) {

            if (key == 0.0) {
                g2d.drawString(Character.toString('\u221E'), 
                    (int) ((borderSize - 5) + (key * modifier)),
                        (int) (paddingTop * 1.5));
            } else {
                g2d.drawString(String.valueOf(TruckSimple.sites.get(key)), 
                    (int) ((borderSize - 5) + (key * modifier)),
                        (int) (paddingTop * 1.5));
            }

            g2d.drawString(String.valueOf(key), 
                (int) ((borderSize - 5) + (key * modifier)), paddingTop);
            g2d.fillOval((int) (borderSize + (key * modifier)), 
                (int) (paddingTop * 1.2), 10, 10);
            g2d.drawLine((int) lastPoint, (int) (paddingTop * 1.2) + 5, 
                (int) (borderSize + (key * modifier)),
                    (int) (paddingTop * 1.2) + 5);
        }

        g2d.drawString(String.valueOf(goalDistance), 
            (int) (((borderSize - 20) + goalDistance * modifier)),
                (int) (paddingTop * 1.2));

        g2d.setColor(new Color(64, 209, 136));

        g2d.fillRect((int) (((borderSize - 5) + 
            TruckSimple.getDistanceFromBase() * modifier)), 
                (int) (paddingTop * 1.2), 20, 13);
        g2d.fillRect(borderSize, borderSize - 17, 20, 13);
    }

}