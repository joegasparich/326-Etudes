# cosc326-desert

## Vehicle:
1 litre = 12 km  
60 litre tank  
Can carry four 20 litre fuel cans  
Fuel and cans are unlimited, but only at the 'base' 

## Write a report giving your answers to the following:
1. Using the vehicle without refuelling, how far into the desert can you safely go?
2. Describe a procedure whereby you could cross the desert in the vehicle.
3. Describe a procedure whereby you could cross the desert and return in the vehicle.
4. Describe a procedure whereby you could cross the desert in the vehicle using the minimum amount of fuel.
5. Describe a procedure whereby you could cross the desert and return in the vehicle using the minimum amount of fuel.

## Each procedure to (acompany report) needs to be in it's own file.
### Procedure Syntax:
The first line is treated as a title and is not processed.
* Each subsequent line (ended by a newline) represents one trip into the desert. It is encoded by a sequence of character/number pairs which mean the following:
* `T23.4` - pick up 23.4 litres and put them into the tank
* `C23.4` - load cans containing 23.4 litres onto the back of the truck (note that the program keeps track of how many cans you have on the truck)
* `F23.4` - drive forward (towards the end of the desert) 23.4 kilometres
* `D23.4` - dump cans containing 23.4 litres at the current position in the desert
* `B23.4` - drive backwards (towards the base) 23.4 kilometres
* `*3 (... ...)` - repeat the two commands in brackets (i.e. T/C/F/D/B) 3 times
* The last line (which must have a newline) should follow this format `#1500.0` which indicates that you used (for example) 1500 litres in total
